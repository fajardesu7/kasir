@extends('admin.main2')
@section('title','Finish Transaction')
@section('content')

<div class="container">
	<h1>Finish Transaction</h1>
</div>


@endsection